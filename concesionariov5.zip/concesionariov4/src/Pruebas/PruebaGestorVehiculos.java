package Pruebas;

public class PruebaGestorVehiculos {

}
